import { motion } from 'motion/react';
import { X, Calendar } from 'lucide-react';
import { Room, Event } from '../data/eventData';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { getRoomImage } from '../data/imageAssets';

interface RoomEventsModalProps {
  room: Room;
  onClose: () => void;
  onCollectStamp: (boothId: string) => void;
  isStampCollected: boolean;
  onEventClick?: (event: Event) => void;
}

export function RoomEventsModal({
  room,
  onClose,
  onCollectStamp,
  isStampCollected,
  onEventClick
}: RoomEventsModalProps) {
  return (
    <>
      {/* Backdrop */}
      <motion.div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm z-30"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      />

      {/* Modal Content */}
      <motion.div
        className="absolute bottom-20 left-4 right-4 z-40 bg-gradient-to-br from-gray-900/98 to-gray-800/98 backdrop-blur-2xl rounded-3xl border border-white/20 shadow-2xl overflow-hidden max-h-[75vh]"
        initial={{ y: 500, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 500, opacity: 0 }}
        transition={{ type: 'spring', damping: 35, stiffness: 400 }}
        drag="y"
        dragConstraints={{ top: 0, bottom: 0 }}
        dragElastic={0.1}
        onDragEnd={(e, { offset, velocity }) => {
          if (offset.y > 100 || velocity.y > 500) {
            onClose();
          }
        }}
      >
        {/* Drag Handle */}
        <div className="flex justify-center pt-3 pb-2 absolute top-0 left-0 right-0 z-10">
          <div className="w-12 h-1.5 bg-white/50 rounded-full shadow-lg" />
        </div>

        {/* Room Image with Overlay */}
        <div className="relative h-52 bg-gradient-to-br from-purple-900/30 to-pink-900/30 flex items-end overflow-hidden">
          <ImageWithFallback
            src={getRoomImage(room.id)}
            alt={room.name}
            className="w-full h-full object-cover"
          />
          
          {/* Dark gradient overlay for readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900/95 via-gray-900/60 to-transparent" />

          {/* Room Info Overlay */}
          <div className="absolute bottom-0 left-0 right-0 px-6 pb-5 pt-8">
            <h2 className="text-2xl font-bold text-white mb-1 drop-shadow-lg">{room.name}</h2>
            <div className="flex items-center gap-2 text-gray-200">
              <Calendar className="w-4 h-4" />
              <p className="text-sm font-medium">
                {room.events.length} {room.events.length === 1 ? 'event' : 'events'} today
              </p>
            </div>
          </div>

          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-black/60 backdrop-blur-sm flex items-center justify-center hover:bg-black/80 transition-colors border border-white/20 z-10"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Events List */}
        <div className="overflow-y-auto max-h-[40vh]">
          {room.events.map((event, index) => (
            <motion.button
              key={event.id}
              className="w-full px-6 py-5 border-b border-white/5 hover:bg-white/5 transition-colors text-left"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => onEventClick?.(event)}
            >
              <div className="flex items-start gap-4">
                <div className="text-purple-400 text-sm font-medium whitespace-nowrap pt-1 min-w-[120px]">
                  {event.time}
                </div>
                <div className="flex-1">
                  <div className="text-white font-semibold leading-relaxed mb-1">
                    {event.title}
                  </div>
                  {event.company && (
                    <div className="text-gray-400 text-xs">{event.company}</div>
                  )}
                </div>
              </div>
            </motion.button>
          ))}
        </div>

        {/* Collect Stamp Button (for booths) */}
        {room.type === 'booth' && (
          <div className="p-6 border-t border-white/10">
            <button
              onClick={() => {
                if (!isStampCollected) {
                  onCollectStamp(room.id);
                }
              }}
              disabled={isStampCollected}
              className={`w-full py-3 px-4 rounded-xl font-medium transition-all ${
                isStampCollected
                  ? 'bg-green-500/30 text-green-300 border border-green-500/50 cursor-not-allowed'
                  : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 shadow-lg'
              }`}
            >
              {isStampCollected ? '✓ Stamp Collected' : 'Collect Stamp'}
            </button>
          </div>
        )}
      </motion.div>
    </>
  );
}