import { motion, AnimatePresence } from 'motion/react';
import { Award, Lock, X } from 'lucide-react';
import { useState } from 'react';
import { getRoomById } from '../data/eventData';
import { LogoHeader } from './Logo';

const allBooths = [
  { id: '109', name: 'Room 109', icon: '🎮' },
  { id: 'rm01', name: 'RM 01', icon: '🥽' },
  { id: 'rm02', name: 'RM 02', icon: '📱' },
  { id: 'chauhaus', name: 'Chauhaus', icon: '☕' },
  { id: '124', name: 'Room 124', icon: '🌐' },
  { id: 'sc01', name: 'SC 01', icon: '💼' },
  { id: 'sc02', name: 'SC 02', icon: '💡' },
  { id: 'sc03', name: 'SC 03', icon: '🚀' }
];

interface PassportScreenProps {
  collectedStamps: string[];
}

interface StampDetail {
  id: string;
  name: string;
  time: string;
}

export function PassportScreen({ collectedStamps }: PassportScreenProps) {
  const progress = (collectedStamps.length / allBooths.length) * 100;
  const [selectedStamp, setSelectedStamp] = useState<StampDetail | null>(null);

  const getStampDetails = (boothId: string): StampDetail | null => {
    const room = getRoomById(boothId);
    if (!room) return null;
    
    return {
      id: boothId,
      name: room.name,
      time: new Date().toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit'
      })
    };
  };

  return (
    <div className="h-full w-full overflow-y-auto pb-24 pt-6 px-4">
      {/* Header */}
      <div className="mb-8 px-2">
        <LogoHeader />
        <div className="flex items-center gap-3 mb-3 mt-4">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Award className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">Passport</h1>
            <p className="text-gray-400 text-sm">Collect all booth stamps</p>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="bg-gray-800/50 rounded-full h-3 overflow-hidden backdrop-blur-sm border border-white/10">
          <motion.div
            className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          />
        </div>
        <div className="text-center mt-2 text-sm text-gray-400">
          <span className="text-white font-semibold">{collectedStamps.length}</span> of{' '}
          <span className="text-white font-semibold">{allBooths.length}</span> booths visited
        </div>
      </div>

      {/* Stamp Grid */}
      <div className="grid grid-cols-2 gap-4 px-2">
        {allBooths.map((booth, index) => {
          const isCollected = collectedStamps.includes(booth.id);
          
          return (
            <motion.div
              key={booth.id}
              className={`relative rounded-2xl border-2 p-6 aspect-square flex flex-col items-center justify-center ${
                isCollected
                  ? 'bg-gradient-to-br from-purple-500/20 to-pink-500/20 border-purple-500/50'
                  : 'bg-gray-800/30 border-gray-700/50'
              }`}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {isCollected ? (
                <>
                  {/* Stamp Effect */}
                  <motion.div
                    className="absolute inset-0 rounded-2xl border-4 border-purple-500/30"
                    initial={{ scale: 1.2, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.3 }}
                  />
                  
                  <motion.div
                    className="text-6xl mb-3"
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ 
                      type: 'spring',
                      stiffness: 200,
                      damping: 15,
                      delay: index * 0.05
                    }}
                  >
                    {booth.icon}
                  </motion.div>
                  
                  <div className="text-white font-semibold text-center text-sm">
                    {booth.name}
                  </div>
                  
                  {/* Checkmark */}
                  <motion.div
                    className="absolute top-2 right-2 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: index * 0.05 + 0.2, type: 'spring' }}
                  >
                    <span className="text-white text-xs">✓</span>
                  </motion.div>

                  {/* Ink Stamp Texture */}
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-purple-600/10 to-pink-600/10 mix-blend-overlay" />
                </>
              ) : (
                <>
                  <Lock className="w-10 h-10 text-gray-600 mb-3" />
                  <div className="text-gray-500 font-medium text-center text-sm">
                    {booth.name}
                  </div>
                  <div className="text-gray-600 text-xs mt-1">Not visited</div>
                </>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Completion Message */}
      {collectedStamps.length === allBooths.length && (
        <motion.div
          className="mt-8 p-6 bg-gradient-to-br from-purple-500/20 to-pink-500/20 border-2 border-purple-500/50 rounded-2xl text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="text-4xl mb-3">🎉</div>
          <h3 className="text-xl font-bold text-white mb-2">Passport Complete!</h3>
          <p className="text-gray-300 text-sm">
            You've visited all booths at HXR Conference 2026
          </p>
        </motion.div>
      )}
    </div>
  );
}