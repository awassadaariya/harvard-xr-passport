import { motion } from 'motion/react';
import { Clock, MapPin } from 'lucide-react';
import { LogoHeader } from './Logo';
import { allSchedule, Event } from '../data/eventData';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { getEventImage } from '../data/imageAssets';

interface ScheduleScreenProps {
  onEventClick?: (event: Event) => void;
}

const scheduleData = [
  {
    timeBlock: '9:00 AM - 12:00 PM',
    items: allSchedule.filter(event => {
      const hour = parseInt(event.time.split(':')[0]);
      return hour >= 9 && hour < 12;
    })
  },
  {
    timeBlock: '12:00 PM - 5:00 PM',
    items: allSchedule.filter(event => {
      const hour = parseInt(event.time.split(':')[0]);
      return hour >= 12 && hour < 17;
    })
  },
  {
    timeBlock: '5:00 PM - 7:00 PM',
    items: allSchedule.filter(event => {
      const hour = parseInt(event.time.split(':')[0]);
      return hour >= 17 || event.time.includes('pm') && hour >= 5;
    })
  }
];

export function ScheduleScreen({ onEventClick }: ScheduleScreenProps) {
  return (
    <div className="h-full w-full overflow-y-auto pb-24 pt-6 px-6">
      {/* Header */}
      <div className="mb-6">
        <LogoHeader />
        <h1 className="text-2xl font-bold text-white mt-4 mb-1">Schedule</h1>
        <p className="text-gray-400 text-sm">
          Full Conference Timeline
        </p>
      </div>

      {/* Schedule Blocks */}
      {scheduleData.map((block, blockIndex) => (
        <motion.div
          key={blockIndex}
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: blockIndex * 0.1 }}
        >
          {/* Time Block Header */}
          <div className="flex items-center gap-3 mb-4">
            <Clock className="w-5 h-5 text-purple-400" />
            <h2 className="text-lg font-semibold text-white">{block.timeBlock}</h2>
          </div>

          {/* Event Cards */}
          <div className="space-y-4">
            {block.items.map((event, itemIndex) => (
              <motion.div
                key={event.id}
                className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl border border-white/10 overflow-hidden cursor-pointer"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: blockIndex * 0.1 + itemIndex * 0.05 }}
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                onClick={() => onEventClick?.(event)}
              >
                {/* Event Image */}
                <div className="relative h-48 bg-gradient-to-br from-purple-900/30 to-pink-900/30 flex items-center justify-center overflow-hidden">
                  <ImageWithFallback
                    src={getEventImage(event.id)}
                    alt={event.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900/90 to-transparent" />

                  {/* Time Badge */}
                  <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-sm rounded-full px-3 py-1.5 flex items-center gap-2 border border-white/20">
                    <Clock className="w-4 h-4 text-purple-400" />
                    <span className="text-white text-xs font-semibold">{event.time}</span>
                  </div>

                  {/* Room Badge */}
                  <div className="absolute bottom-4 left-4 bg-black/60 backdrop-blur-sm rounded-full px-3 py-1.5 flex items-center gap-2 border border-white/20">
                    <MapPin className="w-4 h-4 text-pink-400" />
                    <span className="text-white text-xs font-semibold">{event.room}</span>
                  </div>
                </div>

                {/* Event Info */}
                <div className="p-5">
                  <h3 className="text-xl font-bold text-white mb-2 leading-snug">{event.title}</h3>
                  
                  {/* Speaker/Company */}
                  {(event.speakers && event.speakers.length > 0) || event.company ? (
                    <div className="text-purple-400 text-sm font-medium mb-3">
                      {event.speakers && event.speakers.length > 0 ? (
                        <>
                          {event.speakers[0].name}
                          {event.speakers[0].company && (
                            <span className="text-gray-400"> · {event.speakers[0].company}</span>
                          )}
                        </>
                      ) : (
                        event.company
                      )}
                    </div>
                  ) : null}

                  {/* Description */}
                  <p className="text-gray-300 text-sm leading-relaxed line-clamp-2">
                    {event.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      ))}
    </div>
  );
}