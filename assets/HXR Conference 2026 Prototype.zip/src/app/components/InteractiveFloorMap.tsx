import { useState } from 'react';
import { motion } from 'motion/react';

interface InteractiveFloorMapProps {
  onRoomClick: (roomId: string) => void;
  highlightedRoomId: string | null;
}

// Room data matching the reference layout exactly
const rooms = [
  // Top row
  { 
    id: '109', 
    name: '109', 
    x: '18%', 
    y: '13%', 
    width: '18%', 
    height: '17%',
    bgColor: 'rgba(71, 85, 105, 0.85)',
    borderColor: 'rgba(100, 116, 139, 0.9)'
  },
  { 
    id: 'piper', 
    name: 'Piper', 
    x: '52.5%', 
    y: '13%', 
    width: '35.5%', 
    height: '26.5%',
    bgColor: 'rgba(129, 104, 130, 0.85)',
    borderColor: 'rgba(156, 131, 157, 0.9)'
  },
  
  // Left column
  { 
    id: 'rm01', 
    name: 'RM 01', 
    x: '4.5%', 
    y: '31%', 
    width: '25.5%', 
    height: '19%',
    bgColor: 'rgba(129, 104, 130, 0.85)',
    borderColor: 'rgba(156, 131, 157, 0.9)'
  },
  { 
    id: 'rm02', 
    name: 'RM02', 
    x: '4.5%', 
    y: '50%', 
    width: '20.5%', 
    height: '18%',
    bgColor: 'rgba(129, 104, 130, 0.85)',
    borderColor: 'rgba(156, 131, 157, 0.9)'
  },
  { 
    id: 'chauhaus', 
    name: 'Chauhaus', 
    x: '1.3%', 
    y: '68%', 
    width: '19.5%', 
    height: '18%',
    bgColor: 'rgba(129, 104, 130, 0.75)',
    borderColor: 'rgba(156, 131, 157, 0.85)'
  },
  
  // Bottom right
  { 
    id: '124', 
    name: '124', 
    x: '48.5%', 
    y: '76%', 
    width: '26%', 
    height: '10%',
    bgColor: 'rgba(88, 101, 126, 0.85)',
    borderColor: 'rgba(115, 128, 153, 0.9)'
  },
  
  // Bottom row
  { 
    id: 'sc01', 
    name: 'SC 01', 
    x: '21%', 
    y: '87%', 
    width: '15.5%', 
    height: '8%',
    bgColor: 'rgba(88, 101, 126, 0.85)',
    borderColor: 'rgba(115, 128, 153, 0.9)'
  },
  { 
    id: 'sc02', 
    name: 'SC 02', 
    x: '36.7%', 
    y: '87%', 
    width: '15.5%', 
    height: '8%',
    bgColor: 'rgba(88, 101, 126, 0.85)',
    borderColor: 'rgba(115, 128, 153, 0.9)'
  },
  { 
    id: 'sc03', 
    name: 'SC 03', 
    x: '52.5%', 
    y: '87%', 
    width: '15.5%', 
    height: '8%',
    bgColor: 'rgba(88, 101, 126, 0.85)',
    borderColor: 'rgba(115, 128, 153, 0.9)'
  }
];

// Entry indicators
const entries = [
  { name: 'Cambridge St\nEntry', x: '43.5%', y: '9%', icon: '▼' },
  { name: 'Quincy\nEntry', x: '85%', y: '48%', icon: '◄' },
  { name: 'Lawn\nEntry', x: '7.5%', y: '75%', icon: '►' }
];

export function InteractiveFloorMap({ onRoomClick, highlightedRoomId }: InteractiveFloorMapProps) {
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  return (
    <div className="relative w-full h-full bg-gradient-to-br from-[#1a1a2e] via-[#16213e] to-[#0f1419]">
      {/* Dark background pattern */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
          backgroundSize: '40px 40px',
          pointerEvents: 'none'
        }}
      />

      {/* Map Container */}
      <div className="relative w-full h-full">
        {/* Entry Indicators */}
        {entries.map((entry, idx) => (
          <div
            key={idx}
            className="absolute text-white text-center text-[10px] whitespace-pre-line"
            style={{
              left: entry.x,
              top: entry.y,
              transform: 'translate(-50%, -50%)',
              textShadow: '0 2px 8px rgba(0,0,0,0.8)',
              pointerEvents: 'none'
            }}
          >
            <div className="text-base mb-0.5">{entry.icon}</div>
            <div className="leading-tight">{entry.name}</div>
          </div>
        ))}

        {/* Interactive Room Buttons */}
        {rooms.map((room) => {
          const isHighlighted = highlightedRoomId === room.id || hoveredId === room.id;
          
          return (
            <motion.button
              key={room.id}
              className="absolute"
              style={{
                left: room.x,
                top: room.y,
                width: room.width,
                height: room.height,
                backgroundColor: isHighlighted 
                  ? 'rgba(167, 139, 250, 0.6)' 
                  : room.bgColor,
                border: `2px solid ${isHighlighted ? '#a78bfa' : room.borderColor}`,
                borderRadius: '12px',
                backdropFilter: 'blur(12px)',
                boxShadow: isHighlighted 
                  ? '0 0 24px rgba(167, 139, 250, 0.7), inset 0 2px 4px rgba(255,255,255,0.15)' 
                  : '0 4px 16px rgba(0,0,0,0.3), inset 0 2px 4px rgba(255,255,255,0.1)',
                transition: 'all 0.2s ease'
              }}
              onClick={() => onRoomClick(room.id)}
              onMouseEnter={() => setHoveredId(room.id)}
              onMouseLeave={() => setHoveredId(null)}
              onTouchStart={() => setHoveredId(room.id)}
              onTouchEnd={() => setHoveredId(null)}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
            >
              {/* Room Label */}
              <span 
                className="text-white font-semibold"
                style={{
                  textShadow: '0 2px 10px rgba(0,0,0,0.9)',
                  fontSize: room.id.includes('sc') ? '11px' : '14px'
                }}
              >
                {room.name}
              </span>

              {/* Pulse effect when highlighted */}
              {isHighlighted && (
                <motion.div
                  className="absolute inset-0 rounded-xl border-2 border-purple-400"
                  style={{ pointerEvents: 'none' }}
                  initial={{ opacity: 0.8, scale: 1 }}
                  animate={{ opacity: 0, scale: 1.08 }}
                  transition={{ duration: 1, repeat: Infinity }}
                />
              )}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}