import { motion } from 'motion/react';
import { Home, Calendar, BookOpen } from 'lucide-react';

type Screen = 'map' | 'schedule' | 'passport';

interface BottomNavProps {
  currentScreen: Screen;
  onScreenChange: (screen: Screen) => void;
}

const navItems = [
  { id: 'map' as Screen, label: 'MAP', icon: Home },
  { id: 'schedule' as Screen, label: 'SCHEDULE', icon: Calendar },
  { id: 'passport' as Screen, label: 'PASSPORT', icon: BookOpen }
];

export function BottomNav({ currentScreen, onScreenChange }: BottomNavProps) {
  return (
    <div className="absolute bottom-0 left-0 right-0 z-20">
      <div className="mx-4 mb-4 bg-gray-900/80 backdrop-blur-xl rounded-[2rem] border border-white/20 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-around p-2">
          {navItems.map((item) => {
            const isActive = currentScreen === item.id;
            const Icon = item.icon;
            
            return (
              <button
                key={item.id}
                onClick={() => onScreenChange(item.id)}
                className="relative flex-1 flex flex-col items-center justify-center py-3 px-4 rounded-3xl transition-colors"
              >
                {isActive && (
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-3xl"
                    layoutId="activeTab"
                    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                  />
                )}
                
                <motion.div
                  animate={{
                    scale: isActive ? 1.1 : 1,
                    color: isActive ? '#ffffff' : '#9ca3af'
                  }}
                  transition={{ duration: 0.2 }}
                  className="relative z-10"
                >
                  <Icon className="w-6 h-6 mb-1" />
                </motion.div>
                
                <motion.span
                  animate={{
                    color: isActive ? '#ffffff' : '#9ca3af',
                    fontWeight: isActive ? 600 : 500
                  }}
                  className="text-[10px] tracking-wide relative z-10"
                >
                  {item.label}
                </motion.span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
