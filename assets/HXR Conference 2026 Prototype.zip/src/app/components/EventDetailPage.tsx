import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, MapPin, Clock, Building2, User } from 'lucide-react';
import { Event } from '../data/eventData';
import { CameraStampCollector } from './CameraStampCollector';

interface EventDetailPageProps {
  event: Event;
  onBack: () => void;
  onCollectStamp: (boothId: string) => void;
  isStampCollected: boolean;
}

export function EventDetailPage({
  event,
  onBack,
  onCollectStamp,
  isStampCollected
}: EventDetailPageProps) {
  const [showCamera, setShowCamera] = useState(false);

  const handleCollectStamp = () => {
    setShowCamera(true);
  };

  const handleStampCaptured = () => {
    setShowCamera(false);
    onCollectStamp(event.room.toLowerCase().replace(/\s+/g, ''));
  };

  return (
    <motion.div
      className="absolute inset-0 bg-gradient-to-br from-gray-900 via-purple-900/20 to-pink-900/20 z-50 overflow-y-auto"
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 35, stiffness: 400 }}
    >
      {/* Header */}
      <div className="sticky top-0 z-10 bg-gray-900/80 backdrop-blur-xl border-b border-white/10 px-6 py-4">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-white hover:text-purple-400 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="font-medium">Back</span>
        </button>
      </div>

      {/* Content */}
      <div className="px-6 py-8 pb-24">
        {/* Event Title */}
        <motion.h1
          className="text-3xl font-bold text-white mb-6 leading-tight"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          {event.title}
        </motion.h1>

        {/* Event Info Cards */}
        <motion.div
          className="space-y-3 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center gap-3 text-gray-300">
            <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center">
              <Clock className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <div className="text-xs text-gray-400">Time</div>
              <div className="font-medium">{event.time}</div>
            </div>
          </div>

          <div className="flex items-center gap-3 text-gray-300">
            <div className="w-10 h-10 rounded-full bg-pink-500/20 flex items-center justify-center">
              <MapPin className="w-5 h-5 text-pink-400" />
            </div>
            <div>
              <div className="text-xs text-gray-400">Location</div>
              <div className="font-medium">{event.room}</div>
            </div>
          </div>

          {event.company && (
            <div className="flex items-center gap-3 text-gray-300">
              <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center">
                <Building2 className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <div className="text-xs text-gray-400">Company</div>
                <div className="font-medium">{event.company}</div>
              </div>
            </div>
          )}
        </motion.div>

        {/* Description Section */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h2 className="text-xl font-bold text-white mb-3">Description</h2>
          <p className="text-gray-300 leading-relaxed">{event.description}</p>
        </motion.div>

        {/* Speakers Section */}
        {event.speakers && event.speakers.length > 0 && (
          <motion.div
            className="mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <h2 className="text-xl font-bold text-white mb-4">Speakers</h2>
            <div className="space-y-4">
              {event.speakers.map((speaker, index) => (
                <div
                  key={index}
                  className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl border border-white/10 p-5"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                      <User className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-1">
                        {speaker.name}
                      </h3>
                      <p className="text-sm text-purple-400">{speaker.title}</p>
                      {speaker.company && (
                        <p className="text-xs text-gray-400 mt-1">{speaker.company}</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Collect Stamp Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <button
            onClick={handleCollectStamp}
            disabled={isStampCollected}
            className={`w-full py-4 px-6 rounded-2xl font-semibold text-lg transition-all ${
              isStampCollected
                ? 'bg-green-500/30 text-green-300 border border-green-500/50 cursor-not-allowed'
                : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 shadow-xl hover:shadow-2xl'
            }`}
          >
            {isStampCollected ? '✓ Stamp Collected' : 'Collect Stamp'}
          </button>
        </motion.div>
      </div>

      {/* Camera Interface */}
      {showCamera && (
        <CameraStampCollector
          onCapture={handleStampCaptured}
          onClose={() => setShowCamera(false)}
        />
      )}
    </motion.div>
  );
}