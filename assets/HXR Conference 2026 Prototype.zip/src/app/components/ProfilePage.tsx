import { motion } from 'motion/react';
import { ArrowLeft, User, Mail, Award, Calendar, LogOut, Trophy, Sparkles } from 'lucide-react';

interface ProfilePageProps {
  onBack: () => void;
  collectedStamps: string[];
  userVotes: string[];
}

export function ProfilePage({ onBack, collectedStamps, userVotes }: ProfilePageProps) {
  // Calculate progress
  const totalStamps = 9; // Total available stamps
  const stampProgress = (collectedStamps.length / totalStamps) * 100;

  return (
    <motion.div
      className="absolute inset-0 bg-gradient-to-br from-gray-900 via-purple-900/20 to-pink-900/20 z-50 overflow-y-auto"
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 30, stiffness: 300 }}
    >
      {/* Header */}
      <div className="sticky top-0 z-10 bg-gray-900/80 backdrop-blur-xl border-b border-white/10 px-6 py-4">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-white hover:text-purple-400 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="font-medium">Back</span>
        </button>
      </div>

      {/* Content */}
      <div className="px-6 py-8 pb-24 space-y-6">
        {/* Hero Profile Card */}
        <motion.div
          className="relative bg-gradient-to-br from-purple-600/30 via-pink-600/30 to-purple-600/30 backdrop-blur-xl rounded-3xl border border-white/20 overflow-hidden shadow-2xl"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          {/* Animated background gradient */}
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-pink-500/20 animate-pulse" />
          
          <div className="relative p-8">
            {/* Profile Avatar */}
            <div className="flex flex-col items-center mb-6">
              <div className="relative mb-4">
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shadow-2xl ring-4 ring-white/20">
                  <User className="w-12 h-12 text-white" />
                </div>
                {/* Achievement badge */}
                <div className="absolute -bottom-2 -right-2 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full p-2 shadow-xl border-2 border-gray-900">
                  <Trophy className="w-4 h-4 text-white" />
                </div>
              </div>
              
              <h1 className="text-3xl font-bold text-white mb-1 text-center">Alex Johnson</h1>
              <p className="text-purple-200 text-sm mb-4">Conference Attendee</p>
            </div>

            {/* Email */}
            <div className="flex items-center justify-center gap-2 text-purple-100 bg-white/10 rounded-xl py-3 px-4">
              <Mail className="w-4 h-4" />
              <span className="text-sm">alex.johnson@email.com</span>
            </div>
          </div>
        </motion.div>

        {/* Stats Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-white">Your Activity</h2>
            <Sparkles className="w-5 h-5 text-purple-400" />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            {/* Stamps Card */}
            <motion.div
              className="bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-xl rounded-2xl border border-white/10 p-6 shadow-xl"
              whileHover={{ scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
            >
              <div className="flex flex-col items-center text-center">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500/30 to-purple-600/30 flex items-center justify-center mb-3 border border-purple-500/30">
                  <Award className="w-7 h-7 text-purple-400" />
                </div>
                <span className="text-4xl font-bold text-white mb-1">{collectedStamps.length}</span>
                <p className="text-gray-400 text-xs font-medium">Stamps Collected</p>
                <div className="w-full mt-3 bg-gray-700/50 rounded-full h-1.5 overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-purple-500 to-purple-400"
                    initial={{ width: 0 }}
                    animate={{ width: `${stampProgress}%` }}
                    transition={{ delay: 0.5, duration: 1 }}
                  />
                </div>
              </div>
            </motion.div>

            {/* Votes Card */}
            <motion.div
              className="bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-xl rounded-2xl border border-white/10 p-6 shadow-xl"
              whileHover={{ scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
            >
              <div className="flex flex-col items-center text-center">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-pink-500/30 to-pink-600/30 flex items-center justify-center mb-3 border border-pink-500/30">
                  <Calendar className="w-7 h-7 text-pink-400" />
                </div>
                <span className="text-4xl font-bold text-white mb-1">{userVotes.length}</span>
                <p className="text-gray-400 text-xs font-medium">Projects Voted</p>
                <p className="text-pink-400 text-xs mt-2 font-medium">
                  {userVotes.length === 0 ? 'Start voting!' : 'Keep going!'}
                </p>
              </div>
            </motion.div>
          </div>
        </motion.div>

        {/* Logout Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <button className="w-full bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-xl rounded-2xl border border-white/10 p-4 flex items-center justify-center gap-3 hover:border-red-500/30 hover:bg-red-500/10 transition-all shadow-lg">
            <LogOut className="w-5 h-5 text-gray-400" />
            <span className="text-gray-300 font-medium">Sign Out</span>
          </button>
        </motion.div>

        {/* App Version */}
        <motion.div
          className="text-center pt-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <p className="text-gray-500 text-xs">
            HXR Conference 2026 • v1.0.0
          </p>
        </motion.div>
      </div>
    </motion.div>
  );
}