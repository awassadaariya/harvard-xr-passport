import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Settings, Edit } from 'lucide-react';
import { LogoHeader } from './Logo';
import { InteractiveFloorMap } from './InteractiveFloorMap';
import { RoomEventsModal } from './RoomEventsModal';
import { getRoomById, Event } from '../data/eventData';

interface InteractiveMapScreenProps {
  onCollectStamp: (boothId: string) => void;
  collectedStamps: string[];
  onNavigateToVoting: () => void;
  onNavigateToProfile: () => void;
  onEventClick?: (event: Event) => void;
}

export function InteractiveMapScreen({
  onCollectStamp,
  collectedStamps,
  onNavigateToVoting,
  onNavigateToProfile,
  onEventClick
}: InteractiveMapScreenProps) {
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(null);
  const [highlightedId, setHighlightedId] = useState<string | null>(null);

  const handleRegionClick = (regionId: string) => {
    setHighlightedId(regionId);
    setSelectedRoomId(regionId);
  };

  const selectedRoom = selectedRoomId ? getRoomById(selectedRoomId) : null;

  return (
    <div className="relative h-full w-full overflow-hidden">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-20 px-6 pt-6 pb-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <LogoHeader />
          </div>
          <div className="flex gap-3">
            <button
              onClick={onNavigateToVoting}
              className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center backdrop-blur-sm hover:bg-white/10 transition-colors"
            >
              <Edit className="w-5 h-5 text-white/70" />
            </button>
            <button
              onClick={onNavigateToProfile}
              className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center backdrop-blur-sm hover:bg-white/10 transition-colors"
            >
              <Settings className="w-5 h-5 text-white/70" />
            </button>
          </div>
        </div>
      </div>

      {/* SVG Map Container */}
      <div className="absolute inset-0 flex items-center justify-center p-6 pt-32 pb-24">
        <div className="relative w-full h-full">
          <InteractiveFloorMap
            onRoomClick={handleRegionClick}
            highlightedRoomId={highlightedId}
          />
        </div>
      </div>

      {/* Room Events Modal */}
      <AnimatePresence>
        {selectedRoom && (
          <RoomEventsModal
            room={selectedRoom}
            onClose={() => {
              setSelectedRoomId(null);
              setHighlightedId(null);
            }}
            onCollectStamp={onCollectStamp}
            isStampCollected={collectedStamps.includes(selectedRoom.id)}
            onEventClick={onEventClick}
          />
        )}
      </AnimatePresence>
    </div>
  );
}